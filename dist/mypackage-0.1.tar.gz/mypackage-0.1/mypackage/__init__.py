from . import nyModule
